package com.luiscript.boxpvp;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Visible-only player boxes. Depth testing remains enabled, so blocks hide the box. */
public final class PlayerBoxRenderer {
    private static final float RED = 0.15f;
    private static final float GREEN = 0.88f;
    private static final float BLUE = 1.0f;
    private static final float ALPHA = 1.0f;
    private static final double PADDING = 0.035D;

    private PlayerBoxRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(PlayerBoxRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        if (!BoxConfig.playerBox) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || context.world() == null || mc.screen != null) return;

        Vec3 camera = mc.gameRenderer.getMainCamera().position();
        MultiBufferSource consumers = context.consumers();
        if (consumers == null) return;

        VertexConsumer lines = consumers.getBuffer(RenderTypes.lines());
        double maxDistanceSq = BoxConfig.playerBoxRange * BoxConfig.playerBoxRange;

        for (Player player : context.world().players()) {
            if (player == mc.player || player.isSpectator() || !player.isAlive()) continue;
            if (player.distanceToSqr(mc.player) > maxDistanceSq) continue;

            AABB box = player.getBoundingBox().inflate(PADDING);
            LevelRenderer.renderLineBox(
                    lines,
                    box.minX - camera.x,
                    box.minY - camera.y,
                    box.minZ - camera.z,
                    box.maxX - camera.x,
                    box.maxY - camera.y,
                    box.maxZ - camera.z,
                    RED, GREEN, BLUE, ALPHA
            );
        }
    }
}

package com.luiscript.boxpvp;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/**
 * Criticals por paquetes: justo antes de cada golpe envía una mini "caída" al servidor
 * (sube 0.0625 y vuelve), así el servidor cuenta el golpe como crítico aunque estés en el suelo.
 *
 * Si algún día falla la compilación por esta clase, se puede borrar este archivo junto con
 * las dos referencias a Criticals en BoxPvpClient.java y Cheats.java.
 */
public final class Criticals {
    private static boolean resprint = false;

    private Criticals() {}

    public static void register() {
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            onAttack(entity);
            return InteractionResult.PASS;
        });
    }

    private static void onAttack(Entity target) {
        if (!Cheats.get(Cheats.CRITICALS)) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        ClientPacketListener conn = mc.getConnection();
        if (p == null || conn == null || !(target instanceof LivingEntity)) return;
        if (!p.onGround() || p.isInWater() || p.isInLava() || p.onClimbable() || p.isPassenger()) return;

        // Un golpe corriendo no puede ser crítico: se avisa al servidor que dejas de correr un tick.
        if (p.isSprinting()) {
            conn.send(new ServerboundPlayerCommandPacket(p, ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
            resprint = true;
        }

        double x = p.getX();
        double y = p.getY();
        double z = p.getZ();
        conn.send(new ServerboundMovePlayerPacket.Pos(x, y + 0.0625D, z, false, false));
        conn.send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
    }

    /** Vuelve a avisar que sigues corriendo después del golpe. */
    public static void tick(Minecraft mc) {
        if (!resprint) return;
        resprint = false;
        ClientPacketListener conn = mc.getConnection();
        if (mc.player != null && conn != null && mc.player.isSprinting()) {
            conn.send(new ServerboundPlayerCommandPacket(mc.player, ServerboundPlayerCommandPacket.Action.START_SPRINTING));
        }
    }
}

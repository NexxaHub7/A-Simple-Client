package com.luiscript.boxpvp;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Aviso obligatorio antes de activar cualquier cheat. */
public final class CheatWarningScreen extends Screen {
    private static final long LOCK_MS = 3000L;
    private static final int WHITE = 0xFFF1FBFF;
    private static final int MUTED = 0xFFB9A7AB;
    private static final int RED = 0xFFFF4B5C;

    private final Screen parent;
    private final int cheat;
    private final long openedAt = System.currentTimeMillis();

    public CheatWarningScreen(Screen parent, int cheat) {
        super(Component.literal("VoidX - Advertencia"));
        this.parent = parent;
        this.cheat = cheat;
    }

    private int boxW() {
        return Math.min(400, this.width - 24);
    }

    private int boxH() {
        return 176;
    }

    private int boxX() {
        return (this.width - boxW()) / 2;
    }

    private int boxY() {
        return (this.height - boxH()) / 2;
    }

    private boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private long remainingMs() {
        return Math.max(0L, LOCK_MS - (System.currentTimeMillis() - openedAt));
    }

    private int btnW() {
        return (boxW() - 60) / 2;
    }

    private int btnY() {
        return boxY() + boxH() - 44;
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String text, boolean hover, int edge, boolean enabled) {
        int bg = !enabled ? 0xFF1A1416 : hover ? 0xFF3A1A20 : 0xFF241519;
        g.fill(x, y, x + w, y + h, bg);
        g.fill(x, y, x + w, y + 1, enabled ? edge : 0xFF4A3A3D);
        g.fill(x, y + h - 1, x + w, y + h, enabled ? edge : 0xFF4A3A3D);
        g.drawCenteredString(this.font, Component.literal(text), x + w / 2, y + 10, enabled ? WHITE : 0xFF77686B);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.fill(0, 0, this.width, this.height, 0x99000000);

        int x = boxX();
        int y = boxY();
        int w = boxW();
        int h = boxH();

        double pulse = 0.5D + 0.5D * Math.sin(System.currentTimeMillis() / 160.0D);
        int alpha = 0x99 + (int) (0x66 * pulse);
        int edge = (alpha << 24) | 0x00FF3B4B;

        g.fill(x - 3, y - 3, x + w + 3, y + h + 3, (0x55 << 24) | 0x00FF1030);
        g.fill(x, y, x + w, y + h, 0xF2120A0D);
        g.fill(x, y, x + w, y + 2, edge);
        g.fill(x, y + h - 2, x + w, y + h, edge);
        g.fill(x, y, x + 2, y + h, edge);
        g.fill(x + w - 2, y, x + w, y + h, edge);

        g.drawCenteredString(this.font, Component.literal("! ADVERTENCIA !").withStyle(ChatFormatting.BOLD),
                x + w / 2, y + 14, RED);

        g.pose().pushMatrix();
        g.pose().scale(2.0f, 2.0f);
        g.drawCenteredString(this.font, Component.literal("Podrías Ser Baneado.").withStyle(ChatFormatting.BOLD),
                (x + w / 2) / 2, (y + 34) / 2, RED);
        g.pose().popMatrix();

        String name = Cheats.NAMES[cheat];
        g.drawCenteredString(this.font, Component.literal("Activar \"" + name + "\" puede romper las reglas del servidor"),
                x + w / 2, y + 74, WHITE);
        g.drawCenteredString(this.font, Component.literal("y terminar en una expulsión o un ban permanente."),
                x + w / 2, y + 88, WHITE);
        g.drawCenteredString(this.font, Component.literal("Úsalo bajo tu propia responsabilidad. END = apagar todo."),
                x + w / 2, y + 108, MUTED);

        int bw = btnW();
        int by = btnY();
        int leftX = x + 20;
        int rightX = x + w - 20 - bw;
        button(g, leftX, by, bw, 28, "Cancelar", inside(mouseX, mouseY, leftX, by, bw, 28), 0xFF8AA0A8, true);

        long rem = remainingMs();
        boolean enabled = rem == 0L;
        String label = enabled ? "Continuar" : "Continuar (" + ((rem + 999L) / 1000L) + ")";
        button(g, rightX, by, bw, 28, label, enabled && inside(mouseX, mouseY, rightX, by, bw, 28), RED, enabled);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x();
        double my = event.y();
        int bw = btnW();
        int by = btnY();
        int leftX = boxX() + 20;
        int rightX = boxX() + boxW() - 20 - bw;

        if (inside(mx, my, leftX, by, bw, 28)) {
            onClose();
            return true;
        }
        if (remainingMs() == 0L && inside(mx, my, rightX, by, bw, 28)) {
            Cheats.set(cheat, true);
            Minecraft.getInstance().setScreen(parent);
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}

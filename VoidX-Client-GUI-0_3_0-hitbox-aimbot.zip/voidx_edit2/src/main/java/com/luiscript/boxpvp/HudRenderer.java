package com.luiscript.boxpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * HUD principal de VoidX. Respeta la posición y escala del HUD Editor.
 * El mismo recorrido (layout) sirve para medir (g == null) y para dibujar.
 */
public final class HudRenderer {
    public static final int CARD_W = 170;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int MUTED = 0xFF9DB7C5;
    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private HudRenderer() {}

    public static boolean hasContent() {
        return BoxConfig.cps || BoxConfig.ping || BoxConfig.armor || BoxConfig.coords
                || BoxConfig.counters || BoxConfig.effects || BoxConfig.keystrokes;
    }

    private static int rainbow() {
        float h = (System.currentTimeMillis() % 7000L) / 7000.0f;
        float r = Math.abs(h * 6.0f - 3.0f) - 1.0f;
        float gr = 2.0f - Math.abs(h * 6.0f - 2.0f);
        float b = 2.0f - Math.abs(h * 6.0f - 4.0f);
        int ri = (int) (Math.max(0, Math.min(1, r)) * 255);
        int gi = (int) (Math.max(0, Math.min(1, gr)) * 255);
        int bi = (int) (Math.max(0, Math.min(1, b)) * 255);
        return 0xFF000000 | (ri << 16) | (gi << 8) | bi;
    }

    public static int cyan() {
        return BoxConfig.hudRainbow ? rainbow() : 0xFF7DEBFF;
    }

    /** Alto del HUD sin escalar. */
    public static int height(Minecraft mc) {
        return layout(mc, null, 0);
    }

    /** Dibuja el HUD en (hudX, hudY) con la escala configurada. */
    public static void render(GuiGraphics g, Minecraft mc) {
        int cyan = cyan();
        int h = height(mc);
        float s = BoxConfig.hudScale / 100.0f;

        g.pose().pushMatrix();
        g.pose().translate((float) BoxConfig.hudX, (float) BoxConfig.hudY);
        g.pose().scale(s, s);
        g.fill(0, 0, CARD_W, h, 0xB9080D12);
        g.fill(0, 0, 2, h, cyan);
        layout(mc, g, cyan);
        g.pose().popMatrix();
    }

    private static void label(GuiGraphics g, Minecraft mc, String text, int x, int y) {
        g.drawString(mc.font, text, x + 3, y, MUTED);
    }

    private static int count(Player p, Item item) {
        int n = 0;
        int size = p.inventoryMenu.slots.size();
        for (int i = 9; i < 46 && i < size; i++) {
            ItemStack s = p.inventoryMenu.slots.get(i).getItem();
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    private static void key(GuiGraphics g, Minecraft mc, int x, int y, int w, String text, boolean down, int cyan) {
        int fill = down ? ((0xAA << 24) | (cyan & 0x00FFFFFF)) : 0x66000000;
        g.fill(x, y, x + w, y + 22, fill);
        g.fill(x, y + 21, x + w, y + 22, cyan);
        g.drawCenteredString(mc.font, Component.literal(text), x + w / 2, y + 7, down ? 0xFF001418 : WHITE);
    }

    private static int layout(Minecraft mc, GuiGraphics g, int cyan) {
        Player p = mc.player;
        int x = 5;
        int y = 4;

        if (g != null) g.drawString(mc.font, "VOIDX HUD", x + 4, y, cyan);
        y += 15;

        if (BoxConfig.cps) {
            if (g != null) {
                label(g, mc, "CPS", x, y);
                g.drawString(mc.font, BoxPvpClient.cpsLeft() + "  |  " + BoxPvpClient.cpsRight(), x + 58, y, WHITE);
            }
            y += 18;
        }

        if (BoxConfig.ping && p != null && mc.getConnection() != null) {
            PlayerInfo info = mc.getConnection().getPlayerInfo(p.getUUID());
            if (info != null) {
                if (g != null) {
                    int ping = info.getLatency();
                    int pc = ping > 150 ? 0xFFFF6B7A : ping > 80 ? 0xFFFFD166 : cyan;
                    label(g, mc, "PING", x, y);
                    g.drawString(mc.font, ping + " ms", x + 58, y, pc);
                }
                y += 18;
            }
        }

        if (BoxConfig.coords && p != null) {
            if (g != null) {
                String dir = p.getDirection().getName();
                String d = dir.isEmpty() ? "" : dir.substring(0, 1).toUpperCase();
                label(g, mc, "XYZ", x, y);
                g.drawString(mc.font, p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ() + "  " + d,
                        x + 58, y, WHITE);
            }
            y += 18;
        }

        if (BoxConfig.counters && p != null) {
            if (g != null) {
                int totems = count(p, Items.TOTEM_OF_UNDYING);
                int pots = count(p, Items.SPLASH_POTION);
                int apples = count(p, Items.GOLDEN_APPLE) + count(p, Items.ENCHANTED_GOLDEN_APPLE);
                label(g, mc, "ITEMS", x, y);
                g.drawString(mc.font, "T " + totems + "   P " + pots + "   G " + apples, x + 58, y,
                        totems == 0 ? 0xFFFF6B7A : WHITE);
            }
            y += 18;
        }

        if (BoxConfig.effects && p != null) {
            List<MobEffectInstance> list = new ArrayList<>(p.getActiveEffects());
            if (!list.isEmpty()) {
                if (g != null) label(g, mc, "EFFECTS", x, y);
                y += 13;
                int shown = 0;
                for (MobEffectInstance e : list) {
                    if (shown++ >= 5) break;
                    if (g != null) {
                        int d = e.getDuration();
                        String time = d < 0 ? "∞" : (d / 20 / 60) + ":" + String.format("%02d", (d / 20) % 60);
                        String name = e.getEffect().value().getDisplayName().getString();
                        int color = d >= 0 && d < 100 ? 0xFFFF5555 : WHITE;
                        g.drawString(mc.font, name + " " + (e.getAmplifier() + 1) + "  " + time, x + 8, y, color);
                    }
                    y += 13;
                }
                y += 5;
            }
        }

        if (BoxConfig.armor && p != null) {
            if (g != null) label(g, mc, "ARMOR", x, y);
            y += 13;
            for (EquipmentSlot slot : ARMOR) {
                ItemStack stack = p.getItemBySlot(slot);
                if (stack.isEmpty()) continue;
                if (g != null) {
                    g.renderItem(stack, x, y);
                    if (stack.isDamageableItem()) {
                        int left = stack.getMaxDamage() - stack.getDamageValue();
                        int color = left < stack.getMaxDamage() * 0.2 ? 0xFFFF5555 : WHITE;
                        g.drawString(mc.font, String.valueOf(left), x + 20, y + 4, color);
                    }
                }
                y += 18;
            }
        }

        if (BoxConfig.keystrokes) {
            y += 2;
            if (g != null) {
                int gx = x + 4;
                int col = 29;
                key(g, mc, gx + col, y, 26, "W", mc.options.keyUp.isDown(), cyan);
                key(g, mc, gx, y + 25, 26, "A", mc.options.keyLeft.isDown(), cyan);
                key(g, mc, gx + col, y + 25, 26, "S", mc.options.keyDown.isDown(), cyan);
                key(g, mc, gx + col * 2, y + 25, 26, "D", mc.options.keyRight.isDown(), cyan);
                key(g, mc, gx, y + 50, 26, "L", mc.options.keyAttack.isDown(), cyan);
                key(g, mc, gx + col, y + 50, 26, "_", mc.options.keyJump.isDown(), cyan);
                key(g, mc, gx + col * 2, y + 50, 26, "R", mc.options.keyUse.isDown(), cyan);
            }
            y += 75 + 2;
        }

        return y + 4;
    }
}

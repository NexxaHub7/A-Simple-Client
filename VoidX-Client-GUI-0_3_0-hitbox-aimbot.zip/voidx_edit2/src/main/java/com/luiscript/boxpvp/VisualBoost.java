package com.luiscript.boxpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;

/**
 * Lightweight visual helpers for low-end devices.
 * Fullbright only changes the local gamma option. Progressive chunks changes
 * render distance in small steps, backing off when FPS drops.
 */
public final class VisualBoost {
    private static Double savedGamma = null;
    private static Integer savedRenderDistance = null;
    private static long lastChunkStep;

    private VisualBoost() {}

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;

        applyFullbright(mc);
        progressiveChunks(mc);
    }

    private static void applyFullbright(Minecraft mc) {
        OptionInstance<Double> gamma = mc.options.gamma();
        if (BoxConfig.fullbright) {
            if (savedGamma == null) savedGamma = gamma.get();
            if (gamma.get() < 1.0D) gamma.set(1.0D);
        } else if (savedGamma != null) {
            gamma.set(savedGamma);
            savedGamma = null;
        }
    }

    private static void progressiveChunks(Minecraft mc) {
        OptionInstance<Integer> distance = mc.options.renderDistance();

        if (!BoxConfig.progressiveChunks) {
            if (savedRenderDistance != null) {
                distance.set(savedRenderDistance);
                savedRenderDistance = null;
            }
            return;
        }

        if (savedRenderDistance == null) savedRenderDistance = distance.get();

        long now = System.currentTimeMillis();
        if (now - lastChunkStep < 1800L) return;
        lastChunkStep = now;

        int current = distance.get();
        int fps = mc.getFps();

        // Low-end friendly: grow one chunk at a time only while the game is stable.
        // Never force an aggressive value; the server/client still applies its own limits.
        if (fps >= 50 && current < savedRenderDistance + BoxConfig.chunkBoost) {
            distance.set(current + 1);
        } else if (fps <= 28 && current > Math.max(4, savedRenderDistance - 2)) {
            distance.set(current - 1);
        }
    }

    public static void onDisable(Minecraft mc) {
        if (savedGamma != null) {
            mc.options.gamma().set(savedGamma);
            savedGamma = null;
        }
        if (savedRenderDistance != null) {
            mc.options.renderDistance().set(savedRenderDistance);
            savedRenderDistance = null;
        }
    }
}

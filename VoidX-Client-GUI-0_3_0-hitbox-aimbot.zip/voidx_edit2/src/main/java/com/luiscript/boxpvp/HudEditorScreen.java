package com.luiscript.boxpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class HudEditorScreen extends Screen {
    private boolean dragging;
    private int grabX;
    private int grabY;

    public HudEditorScreen() {
        super(Component.literal("VoidX HUD Editor"));
    }

    private boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private int accent() {
        return BoxConfig.hudRainbow ? HudRenderer.cyan() : 0xFF9B4DFF;
    }

    private int boxW() {
        return Math.max(40, HudRenderer.CARD_W * BoxConfig.hudScale / 100);
    }

    private int boxH() {
        return Math.max(30, HudRenderer.height(Minecraft.getInstance()) * BoxConfig.hudScale / 100);
    }

    @Override
    protected void init() {
        // No vanilla widgets: the editor is fully custom-drawn.
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        int a = accent();
        int scale = BoxConfig.hudScale;
        int bw = boxW();
        int bh = boxH();
        int x = BoxConfig.hudX;
        int y = BoxConfig.hudY;

        g.fill(0, 0, width, 1, a);

        // El HUD real (mismo renderer que en el juego) + marco de edición.
        HudRenderer.render(g, Minecraft.getInstance());
        g.fill(x - 1, y - 1, x + bw + 1, y, a);
        g.fill(x - 1, y + bh, x + bw + 1, y + bh + 1, a);
        g.fill(x - 1, y, x, y + bh, a);
        g.fill(x + bw, y, x + bw + 1, y + bh, a);

        int bx = 16;
        int by = height - 38;
        drawButton(g, bx, by, 92, 24, "- Size", mouseX, mouseY, a);
        drawButton(g, bx + 100, by, 92, 24, "+ Size", mouseX, mouseY, a);
        drawButton(g, bx + 200, by, 92, 24, "Reset", mouseX, mouseY, a);
        drawButton(g, width - 118, by, 102, 24, "Done", mouseX, mouseY, a);

        g.drawString(font, Component.literal("VoidX HUD Editor"), 16, 12, a);
        g.drawString(font, Component.literal("Arrastra el HUD  •  Escala " + scale + "%  •  Posición " + x + ", " + y),
                16, 25, 0xFFAAA3B8);
    }

    private void drawButton(GuiGraphics g, int x, int y, int w, int h, String text, int mx, int my, int a) {
        boolean hover = inside(mx, my, x, y, w, h);
        g.fill(x, y, x + w, y + h, hover ? 0xFF2C2038 : 0xFF18151C);
        g.fill(x, y, x + w, y + 1, a);
        g.drawCenteredString(font, Component.literal(text), x + w / 2, y + 8, 0xFFF4F0FF);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x();
        double my = event.y();

        if (inside(mx, my, BoxConfig.hudX, BoxConfig.hudY, boxW(), boxH())) {
            dragging = true;
            grabX = (int) mx - BoxConfig.hudX;
            grabY = (int) my - BoxConfig.hudY;
            return true;
        }

        int by = height - 38;
        if (inside(mx, my, 16, by, 92, 24)) {
            BoxConfig.hudScale = Math.max(70, BoxConfig.hudScale - 5);
            BoxConfig.save();
            return true;
        }
        if (inside(mx, my, 116, by, 92, 24)) {
            BoxConfig.hudScale = Math.min(140, BoxConfig.hudScale + 5);
            BoxConfig.save();
            return true;
        }
        if (inside(mx, my, 216, by, 92, 24)) {
            BoxConfig.hudX = 8;
            BoxConfig.hudY = 8;
            BoxConfig.hudScale = 100;
            BoxConfig.save();
            return true;
        }
        if (inside(mx, my, width - 118, by, 102, 24)) {
            onClose();
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging && event.button() == 0) {
            BoxConfig.hudX = Math.max(0, Math.min(Math.max(0, width - boxW()), (int) event.x() - grabX));
            BoxConfig.hudY = Math.max(0, Math.min(Math.max(0, height - boxH()), (int) event.y() - grabY));
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (event.button() == 0) {
            dragging = false;
            BoxConfig.save();
            return true;
        }
        return super.mouseReleased(event);
    }
}

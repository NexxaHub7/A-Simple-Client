# VoidX Client — FPS Diagnostics

Minecraft 1.21.11 Fabric client-side utility.

## Added
- FPS counter at the top-right with a black background.
- `L` opens/closes the FPS diagnostics log.
- Session FPS history is kept while Minecraft is running.
- Detects sharp FPS drops and records the measured drop.
- Records a **possible** cause using enabled VoidX performance systems (chunk loading, entity rendering, particles, or general render/frametime load).
- The log remains on screen until closed and keeps recent entries.
- `ESC` also closes the log.

The cause is intentionally labeled as "possible": a client HUD cannot know the exact internal cause of every frame-time spike without a full profiler.


## Visuales añadidos
- Player Box visible para jugadores cercanos, con depth test normal: las paredes ocultan la caja.
- Rango configurable de 8 a 64 bloques.
- HUD rediseñado con tarjeta compacta, colores de ping y acento configurable.
- Utilidades del menú con teclas rápidas y controles adicionales.

### Visual Boost
- Fullbright: sets local gamma to 100% while enabled and restores the previous value when disabled.
- Progressive Chunk Boost: increases render distance one chunk at a time every ~1.8s while FPS is stable, and backs off when FPS drops. The target is the user's original render distance plus up to 4 chunks by default, with no server-side changes.


## v1.3

### Arreglos
- El **HUD Editor** ahora sí se aplica: el HUD del juego usa la posición y la escala guardadas (antes dibujaba siempre en 8, 32).
- El editor muestra el HUD real (mismo renderer), con su tamaño real para arrastrarlo.

### Nuevo en el HUD (pestaña HUD, todo apagado por defecto)
- Coordenadas + dirección, contador de items (tótems / pociones arrojadizas / manzanas doradas), efectos activos con tiempo y Keystrokes (WASD, espacio, clics).

### Utilidades
- **Zoom**: mantén `C` (FOV 30); se restaura al soltar.

### Cheats (pestaña Cheats)
Auto Sprint, Auto Attack, Auto Totem, **Hitbox**, **Criticals** y **Aimbot**.
- Al activar cualquiera aparece un aviso rojo: **"Podrías Ser Baneado."** con **Cancelar** / **Continuar** (Continuar se habilita tras 3 s).
- Los cheats **no se guardan**: al reiniciar el juego quedan apagados.
- `END` = tecla de pánico, apaga todos los cheats al instante (configurable en Controles).
- **Hitbox:** agranda la caja de golpe de los jugadores; slider de 0.00 a +1.50 bloques. El servidor sigue validando la distancia real.
- **Criticals:** antes de cada golpe manda una mini caída por paquetes; si corres, te avisa que dejas de correr un tick. Código aislado en `Criticals.java`.
- **Aimbot:** gira la mira (con suavidad) al jugador más cercano con línea de visión, dentro de un cono frontal de 75°. Solo actúa mientras mantienes el clic izquierdo o con Auto Attack activo. Sliders de rango (3.0-6.0) y suavidad (5-100%).
- Fly y Speed fueron eliminados.

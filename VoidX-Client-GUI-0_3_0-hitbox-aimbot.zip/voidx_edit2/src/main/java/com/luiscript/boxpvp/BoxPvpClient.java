package com.luiscript.boxpvp;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public class BoxPvpClient implements ClientModInitializer {

    private static KeyMapping menuKey;   // tecla por defecto: 1
    private static KeyMapping logKey;    // tecla por defecto: L
    private static KeyMapping zoomKey;   // tecla por defecto: C
    private static KeyMapping panicKey;  // tecla por defecto: END (apaga todos los cheats)

    private static volatile int cpsL = 0;
    private static volatile int cpsR = 0;
    private Integer savedFov = null;

    public static int cpsLeft() { return cpsL; }
    public static int cpsRight() { return cpsR; }

    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean lastLeft = false;
    private boolean lastRight = false;
    private Integer savedLimit = null;

    @Override
    public void onInitializeClient() {
        BoxConfig.load();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("boxpvp_utils", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.boxpvp_utils.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_1, category));
        logKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.boxpvp_utils.fps_log", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_L, category));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.boxpvp_utils.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, category));
        panicKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.boxpvp_utils.panic", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_END, category));

        ClientTickEvents.START_CLIENT_TICK.register(this::fireworkFixed);
        ClientTickEvents.START_CLIENT_TICK.register(Cheats::tickStart);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudRenderCallback.EVENT.register(this::render);
        PlayerBoxRenderer.register();
        Criticals.register();
    }

    // ---------- Firework Fixed ----------
    private void fireworkFixed(Minecraft mc) {
        if (!BoxConfig.fireworkFix || mc.player == null || mc.gameMode == null || mc.screen != null) return;
        if (!mc.player.isFallFlying()) return;

        InteractionHand hand = null;
        if (mc.player.getItemInHand(InteractionHand.MAIN_HAND).is(Items.FIREWORK_ROCKET)) {
            hand = InteractionHand.MAIN_HAND;
        } else if (mc.player.getItemInHand(InteractionHand.MAIN_HAND).isEmpty()
                && mc.player.getItemInHand(InteractionHand.OFF_HAND).is(Items.FIREWORK_ROCKET)) {
            hand = InteractionHand.OFF_HAND;
        }
        if (hand == null) return;

        // Cada clic derecho = un impulso en el aire (nunca se lanza contra un bloque)
        while (mc.options.keyUse.consumeClick()) {
            mc.gameMode.useItem(mc.player, hand);
            mc.player.swing(hand);
        }
        mc.options.keyUse.setDown(false);
    }

    // ---------- Tick ----------
    private void tick(Minecraft mc) {
        while (menuKey.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new BoxMenuScreen());
        }
        while (logKey.consumeClick()) {
            if (mc.screen instanceof LagLogScreen) mc.setScreen(null);
            else if (mc.screen == null) mc.setScreen(new LagLogScreen());
        }

        while (panicKey.consumeClick()) {
            if (Cheats.any()) {
                Cheats.disableAll();
                if (mc.player != null) {
                    mc.player.displayClientMessage(Component.literal("VoidX: todos los cheats apagados."), true);
                }
            }
        }

        LagLog.tick(mc);
        FpsBoost.sync(mc);
        VisualBoost.tick(mc);
        Cheats.tickEnd(mc);
        zoom(mc);

        if (BoxConfig.noParticles && mc.level != null) {
            mc.particleEngine.clearParticles();
        }

        // Ventana sin foco -> pocos FPS; al volver (o al apagar la opcion) se restaura
        OptionInstance<Integer> limit = mc.options.framerateLimit();
        boolean throttle = BoxConfig.bgThrottle && !mc.isWindowActive();
        if (throttle && savedLimit == null) {
            savedLimit = limit.get();
            limit.set(30);
        } else if (!throttle && savedLimit != null) {
            limit.set(savedLimit);
            savedLimit = null;
        }

        // CPS
        long now = System.currentTimeMillis();
        boolean left = mc.options.keyAttack.isDown();
        boolean right = mc.options.keyUse.isDown();
        if (mc.screen == null) {
            if (left && !lastLeft) leftClicks.addLast(now);
            if (right && !lastRight) rightClicks.addLast(now);
        }
        lastLeft = left;
        lastRight = right;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) leftClicks.removeFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) rightClicks.removeFirst();
        cpsL = leftClicks.size();
        cpsR = rightClicks.size();
    }

    // ---------- Zoom ----------
    private void zoom(Minecraft mc) {
        OptionInstance<Integer> fov = mc.options.fov();
        boolean zooming = BoxConfig.zoom && mc.player != null && mc.screen == null && zoomKey.isDown();
        if (zooming && savedFov == null) {
            savedFov = fov.get();
            fov.set(30);
        } else if (!zooming && savedFov != null) {
            fov.set(savedFov);
            savedFov = null;
        }
    }

    // ---------- HUD ----------
    private void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        Cheats.frame(mc, delta.getRealtimeDeltaTicks());
        if (!BoxConfig.hud || mc.player == null || mc.options.hideGui) return;

        // Always-visible FPS badge: black background, top-right.
        if (BoxConfig.fps) {
            String fpsText = "FPS " + mc.getFps();
            int fw = mc.font.width(fpsText);
            int fx = g.guiWidth() - fw - 12;
            g.fill(fx - 6, 6, g.guiWidth() - 6, 25, 0xE9000000);
            g.fill(fx - 6, 6, fx - 4, 25, 0xFF00CFFF);
            g.drawString(mc.font, fpsText, fx, 12, mc.getFps() < 30 ? 0xFFFF6666 : 0xFF7DEBFF);
        }

        if (HudRenderer.hasContent()) HudRenderer.render(g, mc);
    }
}

package com.luiscript.boxpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class BoxMenuScreen extends Screen {
    private static final int WHITE = 0xFFF1FBFF;
    private static final int MUTED = 0xFF9DB7C5;
    private static final int CARD = 0xE60B151B;
    private static final int CARD_HOVER = 0xF3152932;
    private static final int CYAN = 0xFF22E6FF;
    private static final int SKY = 0xFF4FA8FF;
    private static final int GREEN = 0xFF65E6A5;
    private static final int RED = 0xFFFF6B7A;

    private int panelX, panelY, panelW, panelH;
    private int tab = 0;
    private int mouseX, mouseY;
    private int activeSlider = -1;
    private double scrollOffset = 0.0;
    private static final String[] TABS = {"Inicio", "Rendimiento", "HUD", "Gui", "Utilidades", "Cheats", "Ajustes"};

    public BoxMenuScreen() {
        super(Component.literal("VoidX Client"));
    }

    @Override
    protected void init() {
        int baseW = 660 * BoxConfig.guiScale / 100;
        int baseH = 390 * BoxConfig.guiScale / 100;
        panelW = Math.min(baseW, this.width - 24);
        panelH = Math.min(baseH, this.height - 24);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        scrollOffset = clampScroll(scrollOffset);
    }

    private boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private boolean insideContent(double mx, double my) {
        return inside(mx, my, panelX + 164, panelY + 52, panelW - 174, panelH - 64);
    }

    private int rainbow() {
        float h = (System.currentTimeMillis() % 7000L) / 7000.0f;
        float r = Math.abs(h * 6.0f - 3.0f) - 1.0f;
        float g = 2.0f - Math.abs(h * 6.0f - 2.0f);
        float b = 2.0f - Math.abs(h * 6.0f - 4.0f);
        int ri = (int) (Math.max(0, Math.min(1, r)) * 255);
        int gi = (int) (Math.max(0, Math.min(1, g)) * 255);
        int bi = (int) (Math.max(0, Math.min(1, b)) * 255);
        return 0xFF000000 | (ri << 16) | (gi << 8) | bi;
    }

    private int accent() {
        return BoxConfig.guiRainbow ? rainbow() : CYAN;
    }

    private int secondaryAccent() {
        return BoxConfig.guiRainbow ? rainbow() : SKY;
    }

    private int panelColor() {
        int alpha = Math.max(55, Math.min(100, BoxConfig.guiOpacity)) * 255 / 100;
        return (alpha << 24) | 0x00060D12;
    }

    private int maxScroll() {
        return switch (tab) {
            case 0 -> 105;
            case 1 -> 205;
            case 2 -> 140;
            case 3 -> 175;
            case 4 -> 80;
            case 5 -> 235;
            default -> 20;
        };
    }

    private double clampScroll(double value) {
        return Math.max(0, Math.min(maxScroll(), value));
    }

    private int bodyY(int baseY) {
        return (int) Math.round(baseY - scrollOffset);
    }

    private void drawPanel(GuiGraphics g) {
        int a = accent();
        int b = secondaryAccent();

        if (BoxConfig.guiGlow) {
            g.fill(panelX - 4, panelY - 4, panelX + panelW + 4, panelY + panelH + 4, 0x2222E6FF);
            g.fill(panelX - 2, panelY - 2, panelX + panelW + 2, panelY + panelH + 2, 0x4422E6FF);
        }

        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, panelColor());

        if (BoxConfig.guiBorder) {
            g.fill(panelX, panelY, panelX + panelW, panelY + 1, a);
            g.fill(panelX, panelY + panelH - 1, panelX + panelW, panelY + panelH, b);
            g.fill(panelX, panelY, panelX + 1, panelY + panelH, a);
            g.fill(panelX + panelW - 1, panelY, panelX + panelW, panelY + panelH, b);
            // Small corner accents make the frame feel more custom without expensive effects.
            g.fill(panelX + 8, panelY + 2, panelX + 72, panelY + 3, a);
            g.fill(panelX + panelW - 72, panelY + panelH - 3, panelX + panelW - 8, panelY + panelH - 2, b);
        }

        int sideW = 154;
        g.fill(panelX + sideW, panelY + 1, panelX + sideW + 1, panelY + panelH - 1, 0xFF18303A);
        g.fill(panelX + sideW + 1, panelY + 8, panelX + sideW + 2, panelY + panelH - 8, 0x6622E6FF);

        ItemStack star = new ItemStack(Items.PRISMARINE_SHARD);
        g.renderItem(star, panelX + panelW - 42, panelY + 12);
        g.drawString(this.font, Component.literal("VOIDX"), panelX + 18, panelY + 17, WHITE);
        g.drawString(this.font, Component.literal("CLIENT"), panelX + 19, panelY + 30, a);
        g.drawString(this.font, Component.literal("KEY 1"), panelX + 101, panelY + 24, MUTED);

        for (int i = 0; i < TABS.length; i++) {
            int y = panelY + 58 + i * 36;
            boolean selected = tab == i;
            boolean hover = inside(mouseX, mouseY, panelX + 10, y, sideW - 20, 30);
            int bg = selected ? 0xCC0B6E88 : hover ? 0x99305A70 : 0x66101A20;
            g.fill(panelX + 10, y, panelX + sideW - 10, y + 30, bg);
            if (selected) {
                g.fill(panelX + 10, y, panelX + 13, y + 30, a);
                g.fill(panelX + 13, y, panelX + sideW - 10, y + 1, b);
            }
            drawTabIcon(g, panelX + 25, y + 15, i, selected ? a : MUTED);
            g.drawString(this.font, Component.literal(TABS[i]), panelX + 40, y + 9, selected ? WHITE : MUTED);
        }

        g.drawString(this.font, Component.literal("VOIDX  •  1.4"), panelX + 17, panelY + panelH - 22, MUTED);
        g.drawString(this.font, Component.literal("●"), panelX + 105, panelY + panelH - 22, a);
    }

    private void drawTabIcon(GuiGraphics g, int x, int y, int index, int color) {
        String icon = switch (index) {
            case 0 -> "◆";
            case 1 -> "⚡";
            case 2 -> "◇";
            case 3 -> "✦";
            case 4 -> "✚";
            case 5 -> "☠";
            default -> "⚙";
        };
        g.drawCenteredString(this.font, Component.literal(icon), x, y - 5, color);
    }

    private void title(GuiGraphics g, String name, String subtitle) {
        int x = panelX + 176;
        g.drawString(this.font, Component.literal(name), x, panelY + 18, WHITE);
        g.drawString(this.font, Component.literal(subtitle), x, panelY + 32, MUTED);
        g.fill(x, panelY + 46, x + panelW - 194, panelY + 47, 0xFF153540);
        g.fill(x, panelY + 47, x + 86, panelY + 48, accent());
    }

    private void card(GuiGraphics g, int x, int y, int w, int h, String name, String desc, boolean active) {
        boolean hover = inside(mouseX, mouseY, x, y, w, h);
        int a = accent();
        g.fill(x, y, x + w, y + h, hover ? CARD_HOVER : CARD);
        g.fill(x, y, x + 3, y + h, active ? a : 0xFF263943);
        g.fill(x + 8, y + h - 2, x + w - 8, y + h - 1, 0x662B91A8);
        g.drawString(this.font, Component.literal(name), x + 13, y + 9, WHITE);
        g.drawString(this.font, Component.literal(desc), x + 13, y + 23, MUTED);
        g.drawString(this.font, Component.literal(active ? "ON" : "OFF"), x + w - (active ? 28 : 34), y + 9, active ? GREEN : RED);
    }

    private void switchRow(GuiGraphics g, int y, String name, String desc, boolean value) {
        int x = panelX + 176;
        int w = panelW - 194;
        boolean hover = inside(mouseX, mouseY, x, y, w, 38);
        int a = accent();
        g.fill(x, y, x + w, y + 38, hover ? CARD_HOVER : CARD);
        g.fill(x, y, x + 2, y + 38, value ? a : 0xFF263943);
        g.drawString(this.font, Component.literal(name), x + 12, y + 7, WHITE);
        g.drawString(this.font, Component.literal(desc), x + 12, y + 21, MUTED);
        int sx = x + w - 50;
        int sy = y + 10;
        g.fill(sx, sy, sx + 34, sy + 17, value ? 0xFF0C7F99 : 0xFF26333A);
        g.fill(value ? sx + 20 : sx + 3, sy + 3, value ? sx + 31 : sx + 14, sy + 14, WHITE);
    }

    private void drawHome(GuiGraphics g) {
        int x = panelX + 176;
        int y = bodyY(panelY + 62);
        int a = accent();
        g.fill(x, y, x + panelW - 194, y + 76, 0xD9081820);
        g.fill(x, y, x + 4, y + 76, a);
        g.drawString(this.font, Component.literal("VOIDX"), x + 16, y + 14, a);
        g.drawString(this.font, Component.literal("PLAY DIFFERENT"), x + 16, y + 30, WHITE);
        g.drawString(this.font, Component.literal("Performance • HUD • GUI • Utilities"), x + 16, y + 50, MUTED);
        g.renderItem(new ItemStack(Items.PRISMARINE_CRYSTALS), x + panelW - 226, y + 17);

        int cw = (panelW - 206) / 3;
        int cy = y + 90;
        card(g, x, cy, cw, 56, "FPS Boost", "Rendimiento", BoxConfig.boost);
        card(g, x + cw + 8, cy, cw, 56, "HUD", "Información", BoxConfig.hud);
        card(g, x + (cw + 8) * 2, cy, cw, 56, "GUI", "Personalización", true);
        g.drawString(this.font, Component.literal("Novedades"), x, cy + 78, a);
        g.drawString(this.font, Component.literal("Cyan UI • bordes • glow ligero • scroll"), x, cy + 94, MUTED);

        g.fill(x, cy + 116, x + panelW - 194, cy + 154, CARD);
        g.drawString(this.font, Component.literal("Smooth UI"), x + 12, cy + 126, WHITE);
        g.drawString(this.font, Component.literal("Todo queda recortado dentro del panel."), x + 12, cy + 142, MUTED);

        g.fill(x, cy + 166, x + panelW - 194, cy + 204, CARD);
        g.drawString(this.font, Component.literal("Low-Lag Effects"), x + 12, cy + 176, WHITE);
        g.drawString(this.font, Component.literal("Sin shaders, partículas ni overlays pesados."), x + 12, cy + 192, MUTED);
    }

    private void drawPerformance(GuiGraphics g) {
        int y = bodyY(panelY + 62);
        int x = panelX + 176;
        int a = accent();
        switchRow(g, y, "FPS Stabilizer", "Evita bajones bruscos y recupera distancia lentamente.", BoxConfig.fpsStabilizer);
        switchRow(g, y + 46, "Entity Distance", "Reduce el renderizado de entidades lejanas.", BoxConfig.entityDistance);
        switchRow(g, y + 92, "Particle Manager", "Mantiene las partículas en un nivel ligero.", BoxConfig.particleManager);
        switchRow(g, y + 138, "Progressive Chunks", "Sube la distancia por etapas para evitar picos al cargar terreno.", BoxConfig.progressiveChunks);
        switchRow(g, y + 184, "FPS Boost", "Preset general de rendimiento del cliente.", BoxConfig.boost);
        switchRow(g, y + 230, "Sin partículas extra", "Limpia partículas activas si empiezan a acumularse.", BoxConfig.noParticles);
        switchRow(g, y + 276, "Chunk Boost", "Carga más distancia de forma progresiva; retrocede si cae el FPS.", BoxConfig.progressiveChunks);
        g.drawString(this.font, Component.literal("+" + BoxConfig.chunkBoost + " chunks máximo • 1 chunk por etapa • anti-spike"), x, y + 322, MUTED);
        g.drawString(this.font, Component.literal("VOIDX PERFORMANCE"), x, y + 278, a);
        g.drawString(this.font, Component.literal("Prioridad: estabilidad y frametime antes que FPS pico."), x, y + 295, MUTED);
    }

    private void drawHud(GuiGraphics g) {
        int y = bodyY(panelY + 62);
        int x = panelX + 176;
        titleless(g, "HUD");
        switchRow(g, y, "HUD principal", "Muestra el HUD de VoidX.", BoxConfig.hud);
        switchRow(g, y + 46, "CPS", "Contador de clics por segundo.", BoxConfig.cps);
        switchRow(g, y + 92, "FPS", "Muestra los FPS actuales.", BoxConfig.fps);
        switchRow(g, y + 138, "Ping", "Muestra la latencia del servidor.", BoxConfig.ping);
        switchRow(g, y + 184, "Armadura", "Muestra el estado de la armadura.", BoxConfig.armor);
        switchRow(g, y + 230, "Coordenadas", "XYZ y dirección en el HUD.", BoxConfig.coords);
        switchRow(g, y + 276, "Contador de items", "Tótems, pociones y manzanas doradas del inventario.", BoxConfig.counters);
        switchRow(g, y + 322, "Efectos", "Pociones activas con tiempo restante.", BoxConfig.effects);
        switchRow(g, y + 368, "Keystrokes", "Teclas WASD, espacio y clics en pantalla.", BoxConfig.keystrokes);
        drawButton(g, x, y + 414, 150, 30, "Edit HUD", mouseX, mouseY, accent());
        g.drawString(this.font, Component.literal("Posición: " + BoxConfig.hudX + ", " + BoxConfig.hudY + "   Escala: " + BoxConfig.hudScale + "%"), x + 160, y + 424, MUTED);
    }

    private void titleless(GuiGraphics g, String ignored) {
        // Kept intentionally empty: the title is rendered fixed above the scrollable area.
    }

    private void drawGui(GuiGraphics g) {
        int y = bodyY(panelY + 62);
        int x = panelX + 176;
        int w = panelW - 194;
        switchRow(g, y, "Bordes", "Marco cyan limpio alrededor del panel.", BoxConfig.guiBorder);
        switchRow(g, y + 46, "Glow", "Brillo ligero, limitado y barato.", BoxConfig.guiGlow);
        switchRow(g, y + 92, "Rainbow", "Acento de color animado de bajo coste.", BoxConfig.guiRainbow);
        switchRow(g, y + 138, "HUD Rainbow", "Acento rainbow también para el HUD.", BoxConfig.hudRainbow);

        int cy = y + 190;
        g.fill(x, cy, x + w, cy + 78, CARD);
        g.drawString(this.font, Component.literal("Tamaño de GUI"), x + 12, cy + 10, WHITE);
        drawButton(g, x + 12, cy + 31, 72, 28, "−", mouseX, mouseY, accent());
        g.drawCenteredString(this.font, Component.literal(BoxConfig.guiScale + "%"), x + 122, cy + 39, WHITE);
        drawButton(g, x + 168, cy + 31, 72, 28, "+", mouseX, mouseY, accent());
        g.drawString(this.font, Component.literal("Opacidad: " + BoxConfig.guiOpacity + "%"), x + 260, cy + 15, MUTED);
        drawButton(g, x + 260, cy + 34, 70, 25, "−", mouseX, mouseY, accent());
        drawButton(g, x + 338, cy + 34, 70, 25, "+", mouseX, mouseY, accent());

        g.fill(x, cy + 90, x + w, cy + 132, CARD);
        g.drawString(this.font, Component.literal("Tema"), x + 12, cy + 101, accent());
        g.drawString(this.font, Component.literal("VOIDX CYAN • Azul • Celeste"), x + 12, cy + 117, WHITE);
        g.fill(x + w - 88, cy + 103, x + w - 12, cy + 108, CYAN);
        g.fill(x + w - 88, cy + 111, x + w - 42, cy + 116, SKY);

        g.fill(x, cy + 144, x + w, cy + 198, CARD);
        g.drawString(this.font, Component.literal("Decoración"), x + 12, cy + 154, WHITE);
        g.drawString(this.font, Component.literal("Bordes dobles • líneas cyan • iconos MC"), x + 12, cy + 171, MUTED);
        g.drawString(this.font, Component.literal("Todo se dibuja en pantalla, sin texturas pesadas."), x + 12, cy + 187, MUTED);

        g.fill(x, cy + 210, x + w, cy + 266, CARD);
        g.drawString(this.font, Component.literal("Scroll"), x + 12, cy + 220, WHITE);
        g.drawString(this.font, Component.literal("Usa la rueda del mouse para subir y bajar."), x + 12, cy + 237, MUTED);
        g.drawString(this.font, Component.literal("Las opciones nunca se salen del marco."), x + 12, cy + 253, MUTED);
    }

    private void drawUtilities(GuiGraphics g) {
        int y = bodyY(panelY + 62);
        int x = panelX + 176;
        int w = panelW - 194;
        switchRow(g, y, "Firework Fixed", "Ajuste de uso de fuegos artificiales mientras vuelas.", BoxConfig.fireworkFix);
        switchRow(g, y + 46, "Player Box", "Caja alrededor de jugadores cercanos; las paredes la ocultan.", BoxConfig.playerBox);
        switchRow(g, y + 92, "Fullbright", "Iluminación local al máximo; no modifica el mundo ni el servidor.", BoxConfig.fullbright);
        switchRow(g, y + 138, "Zoom", "Mantén C para acercar la vista (FOV 30).", BoxConfig.zoom);
        g.fill(x, y + 184, x + w, y + 232, CARD);
        g.drawString(this.font, Component.literal("Rango de Player Box"), x + 12, y + 195, accent());
        g.drawString(this.font, Component.literal(BoxConfig.playerBoxRange + " bloques"), x + 12, y + 213, WHITE);
        drawButton(g, x + 160, y + 194, 52, 25, "−", mouseX, mouseY, accent());
        drawButton(g, x + 218, y + 194, 52, 25, "+", mouseX, mouseY, accent());
        g.fill(x, y + 244, x + w, y + 294, CARD);
        g.drawString(this.font, Component.literal("Teclas rápidas"), x + 12, y + 254, accent());
        g.drawString(this.font, Component.literal("1 = menú  •  L = FPS Log  •  C = zoom  •  END = apagar cheats"), x + 12, y + 272, WHITE);
    }

    private static final String[] SLIDER_NAMES = {"Tamaño de Hitbox", "Rango de Aimbot", "Suavidad de Aimbot"};
    private static final int SLIDERS = 3;

    private int sliderMin(int i) {
        return switch (i) {
            case 0 -> 0;
            case 1 -> 30;
            default -> 5;
        };
    }

    private int sliderMax(int i) {
        return switch (i) {
            case 0 -> 150;
            case 1 -> 60;
            default -> 100;
        };
    }

    private int sliderStep(int i) {
        return i == 1 ? 1 : 5;
    }

    private int sliderGet(int i) {
        return switch (i) {
            case 0 -> BoxConfig.hitboxSize;
            case 1 -> BoxConfig.aimRange;
            default -> BoxConfig.aimSmooth;
        };
    }

    private void sliderSet(int i, int v) {
        switch (i) {
            case 0 -> BoxConfig.hitboxSize = v;
            case 1 -> BoxConfig.aimRange = v;
            default -> BoxConfig.aimSmooth = v;
        }
    }

    private String sliderText(int i) {
        int v = sliderGet(i);
        return switch (i) {
            case 0 -> "+" + (v / 100) + "." + String.format("%02d", v % 100) + " bloques";
            case 1 -> (v / 10) + "." + (v % 10) + " bloques";
            default -> v + "%";
        };
    }

    private void updateSlider(int i, double mx) {
        int tx = panelX + 176 + 12;
        int tw = panelW - 194 - 24;
        double frac = Math.max(0.0, Math.min(1.0, (mx - tx) / tw));
        int min = sliderMin(i);
        int max = sliderMax(i);
        int step = sliderStep(i);
        int v = min + (int) Math.round(((max - min) * frac) / step) * step;
        sliderSet(i, Math.max(min, Math.min(max, v)));
    }

    private void drawSlider(GuiGraphics g, int i, int x, int cy, int w) {
        int a = accent();
        g.fill(x, cy, x + w, cy + 46, CARD);
        g.fill(x, cy, x + 2, cy + 46, a);
        g.drawString(this.font, Component.literal(SLIDER_NAMES[i]), x + 12, cy + 8, WHITE);
        String text = sliderText(i);
        g.drawString(this.font, Component.literal(text), x + w - 12 - this.font.width(text), cy + 8, a);
        int tx = x + 12;
        int tw = w - 24;
        int ty = cy + 30;
        double frac = (sliderGet(i) - sliderMin(i)) / (double) (sliderMax(i) - sliderMin(i));
        int kx = tx + (int) Math.round(frac * tw);
        g.fill(tx, ty, tx + tw, ty + 6, 0xFF26333A);
        g.fill(tx, ty, kx, ty + 6, a);
        g.fill(kx - 3, ty - 4, kx + 3, ty + 10, WHITE);
    }

    private void drawCheats(GuiGraphics g) {
        int y = bodyY(panelY + 62);
        int x = panelX + 176;
        int w = panelW - 194;
        g.fill(x, y, x + w, y + 38, 0xE63A0E14);
        g.fill(x, y, x + 3, y + 38, RED);
        g.drawString(this.font, Component.literal("RIESGO DE BAN"), x + 12, y + 7, RED);
        g.drawString(this.font, Component.literal("Cada activación pide confirmación. END apaga todo."), x + 12, y + 21, MUTED);
        for (int i = 0; i < Cheats.COUNT; i++) {
            switchRow(g, y + 48 + i * 46, Cheats.NAMES[i], Cheats.DESCS[i], Cheats.get(i));
        }
        int sy = y + 48 + Cheats.COUNT * 46;
        for (int i = 0; i < SLIDERS; i++) {
            drawSlider(g, i, x, sy + i * 54, w);
        }
        int fy = sy + SLIDERS * 54;
        g.fill(x, fy, x + w, fy + 44, CARD);
        g.drawString(this.font, Component.literal("Solo para esta sesión"), x + 12, fy + 9, accent());
        g.drawString(this.font, Component.literal("Al reiniciar el juego todos los cheats quedan apagados."), x + 12, fy + 25, MUTED);
    }

    private void drawSettings(GuiGraphics g) {
        int x = panelX + 176;
        int y = bodyY(panelY + 62);
        g.fill(x, y, x + panelW - 194, y + 72, CARD);
        g.drawString(this.font, Component.literal("VoidX Client"), x + 14, y + 12, WHITE);
        g.drawString(this.font, Component.literal("Minecraft 1.21.11  •  Fabric"), x + 14, y + 29, MUTED);
        g.drawString(this.font, Component.literal("Cyan UI • scroll • bordes • bajo coste"), x + 14, y + 46, MUTED);
        drawButton(g, x, y + 88, 170, 34, "Cerrar VoidX", mouseX, mouseY, accent());
    }

    private void drawButton(GuiGraphics g, int x, int y, int w, int h, String text, int mx, int my, int a) {
        boolean hover = inside(mx, my, x, y, w, h);
        g.fill(x, y, x + w, y + h, hover ? 0xFF14313A : 0xFF0D1B21);
        g.fill(x, y, x + w, y + 1, a);
        g.fill(x, y + h - 1, x + w, y + h, 0xFF164A5A);
        g.drawCenteredString(this.font, Component.literal(text), x + w / 2, y + 10, WHITE);
    }

    private void renderTabTitle(GuiGraphics g) {
        switch (tab) {
            case 0 -> title(g, "Bienvenido a VoidX", "Panel flotante • fondo del mundo visible • controles propios");
            case 1 -> title(g, "Rendimiento", "Ajustes rápidos pensados para jugar más estable.");
            case 2 -> title(g, "HUD", "Información limpia y un editor visual sin widgets vanilla.");
            case 3 -> title(g, "Gui", "Cyan UI • bordes • decoración • opciones sin lag.");
            case 4 -> title(g, "Utilidades", "Pequeñas funciones para PvP y movilidad.");
            case 5 -> title(g, "Cheats", "Ventajas que pueden darte un ban. Úsalas con cuidado.");
            default -> title(g, "Ajustes", "Información del cliente y acciones rápidas.");
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        drawPanel(g);
        renderTabTitle(g);

        int left = panelX + 164;
        int top = panelY + 52;
        int right = panelX + panelW - 10;
        int bottom = panelY + panelH - 11;
        g.enableScissor(left, top, right, bottom);
        switch (tab) {
            case 0 -> drawHome(g);
            case 1 -> drawPerformance(g);
            case 2 -> drawHud(g);
            case 3 -> drawGui(g);
            case 4 -> drawUtilities(g);
            case 5 -> drawCheats(g);
            default -> drawSettings(g);
        }
        g.disableScissor();

        int a = accent();
        int max = maxScroll();
        if (max > 0) {
            int trackX = panelX + panelW - 7;
            int trackTop = top + 2;
            int trackBottom = bottom - 2;
            g.fill(trackX, trackTop, trackX + 2, trackBottom, 0x55243B43);
            int thumbH = Math.max(24, (trackBottom - trackTop) * (trackBottom - trackTop) / (trackBottom - trackTop + max));
            int thumbY = trackTop + (int) ((trackBottom - trackTop - thumbH) * (scrollOffset / max));
            g.fill(trackX, thumbY, trackX + 2, thumbY + thumbH, a);
        }
        g.drawString(this.font, Component.literal("● ONLINE"), panelX + panelW - 76, panelY + panelH - 22, GREEN);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontalAmount, double verticalAmount) {
        if (insideContent(mx, my) && maxScroll() > 0) {
            scrollOffset = clampScroll(scrollOffset - verticalAmount * 28.0);
            return true;
        }
        return super.mouseScrolled(mx, my, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x();
        double my = event.y();
        int sideW = 154;

        for (int i = 0; i < TABS.length; i++) {
            int y = panelY + 58 + i * 36;
            if (inside(mx, my, panelX + 10, y, sideW - 20, 30)) {
                tab = i;
                scrollOffset = 0;
                return true;
            }
        }

        if (!insideContent(mx, my)) return super.mouseClicked(event, doubleClick);

        int x = panelX + 176;
        int w = panelW - 194;
        int y = bodyY(panelY + 62);

        if (tab == 1) {
            if (inside(mx, my, x, y, w, 38)) BoxConfig.fpsStabilizer = !BoxConfig.fpsStabilizer;
            else if (inside(mx, my, x, y + 46, w, 38)) BoxConfig.entityDistance = !BoxConfig.entityDistance;
            else if (inside(mx, my, x, y + 92, w, 38)) BoxConfig.particleManager = !BoxConfig.particleManager;
            else if (inside(mx, my, x, y + 138, w, 38)) BoxConfig.progressiveChunks = !BoxConfig.progressiveChunks;
            else if (inside(mx, my, x, y + 184, w, 38)) BoxConfig.boost = !BoxConfig.boost;
            else if (inside(mx, my, x, y + 230, w, 38)) BoxConfig.noParticles = !BoxConfig.noParticles;
            else if (inside(mx, my, x, y + 276, w, 38)) BoxConfig.progressiveChunks = !BoxConfig.progressiveChunks;
            else return super.mouseClicked(event, doubleClick);
            BoxConfig.save();
            return true;
        }
        if (tab == 2) {
            if (inside(mx, my, x, y, w, 38)) BoxConfig.hud = !BoxConfig.hud;
            else if (inside(mx, my, x, y + 46, w, 38)) BoxConfig.cps = !BoxConfig.cps;
            else if (inside(mx, my, x, y + 92, w, 38)) BoxConfig.fps = !BoxConfig.fps;
            else if (inside(mx, my, x, y + 138, w, 38)) BoxConfig.ping = !BoxConfig.ping;
            else if (inside(mx, my, x, y + 184, w, 38)) BoxConfig.armor = !BoxConfig.armor;
            else if (inside(mx, my, x, y + 230, w, 38)) BoxConfig.coords = !BoxConfig.coords;
            else if (inside(mx, my, x, y + 276, w, 38)) BoxConfig.counters = !BoxConfig.counters;
            else if (inside(mx, my, x, y + 322, w, 38)) BoxConfig.effects = !BoxConfig.effects;
            else if (inside(mx, my, x, y + 368, w, 38)) BoxConfig.keystrokes = !BoxConfig.keystrokes;
            else if (inside(mx, my, x, y + 414, 150, 30)) {
                Minecraft.getInstance().setScreen(new HudEditorScreen());
                return true;
            } else return super.mouseClicked(event, doubleClick);
            BoxConfig.save();
            return true;
        }
        if (tab == 3) {
            if (inside(mx, my, x, y, w, 38)) BoxConfig.guiBorder = !BoxConfig.guiBorder;
            else if (inside(mx, my, x, y + 46, w, 38)) BoxConfig.guiGlow = !BoxConfig.guiGlow;
            else if (inside(mx, my, x, y + 92, w, 38)) BoxConfig.guiRainbow = !BoxConfig.guiRainbow;
            else if (inside(mx, my, x, y + 138, w, 38)) BoxConfig.hudRainbow = !BoxConfig.hudRainbow;
            else {
                int cy = y + 190;
                if (inside(mx, my, x + 12, cy + 31, 72, 28)) BoxConfig.guiScale = Math.max(85, BoxConfig.guiScale - 5);
                else if (inside(mx, my, x + 168, cy + 31, 72, 28)) BoxConfig.guiScale = Math.min(115, BoxConfig.guiScale + 5);
                else if (inside(mx, my, x + 260, cy + 34, 70, 25)) BoxConfig.guiOpacity = Math.max(55, BoxConfig.guiOpacity - 5);
                else if (inside(mx, my, x + 338, cy + 34, 70, 25)) BoxConfig.guiOpacity = Math.min(100, BoxConfig.guiOpacity + 5);
                else return super.mouseClicked(event, doubleClick);
                BoxConfig.save();
                this.init();
                return true;
            }
            BoxConfig.save();
            return true;
        }
        if (tab == 4) {
            if (inside(mx, my, x, y, w, 38)) BoxConfig.fireworkFix = !BoxConfig.fireworkFix;
            else if (inside(mx, my, x, y + 46, w, 38)) BoxConfig.playerBox = !BoxConfig.playerBox;
            else if (inside(mx, my, x, y + 92, w, 38)) BoxConfig.fullbright = !BoxConfig.fullbright;
            else if (inside(mx, my, x, y + 138, w, 38)) BoxConfig.zoom = !BoxConfig.zoom;
            else if (inside(mx, my, x + 160, y + 194, 52, 25)) BoxConfig.playerBoxRange = Math.max(8, BoxConfig.playerBoxRange - 8);
            else if (inside(mx, my, x + 218, y + 194, 52, 25)) BoxConfig.playerBoxRange = Math.min(64, BoxConfig.playerBoxRange + 8);
            else return super.mouseClicked(event, doubleClick);
            BoxConfig.save();
            return true;
        }
        if (tab == 5) {
            int sy = y + 48 + Cheats.COUNT * 46;
            for (int i = 0; i < SLIDERS; i++) {
                if (inside(mx, my, x + 6, sy + i * 54 + 20, w - 12, 24)) {
                    activeSlider = i;
                    updateSlider(i, mx);
                    return true;
                }
            }
            for (int i = 0; i < Cheats.COUNT; i++) {
                if (inside(mx, my, x, y + 48 + i * 46, w, 38)) {
                    if (Cheats.get(i)) Cheats.set(i, false);
                    else Minecraft.getInstance().setScreen(new CheatWarningScreen(this, i));
                    return true;
                }
            }
            return super.mouseClicked(event, doubleClick);
        }
        if (tab == 6 && inside(mx, my, x, y + 88, 170, 34)) {
            onClose();
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (activeSlider >= 0 && event.button() == 0) {
            updateSlider(activeSlider, event.x());
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (activeSlider >= 0 && event.button() == 0) {
            activeSlider = -1;
            BoxConfig.save();
            return true;
        }
        return super.mouseReleased(event);
    }
}

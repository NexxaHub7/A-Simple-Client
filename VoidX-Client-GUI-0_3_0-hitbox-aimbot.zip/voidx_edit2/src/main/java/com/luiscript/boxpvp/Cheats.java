package com.luiscript.boxpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Cheats de VoidX. Todos arrancan APAGADOS en cada sesión (no se guardan en la config)
 * y activarlos desde el menú siempre pasa por {@link CheatWarningScreen}.
 */
public final class Cheats {
    public static final int SPRINT = 0;
    public static final int AUTO_ATTACK = 1;
    public static final int AUTO_TOTEM = 2;
    public static final int HITBOX = 3;
    public static final int CRITICALS = 4;
    public static final int AIMBOT = 5;
    public static final int COUNT = 6;

    public static final String[] NAMES = {"Auto Sprint", "Auto Attack", "Auto Totem", "Hitbox", "Criticals", "Aimbot"};
    public static final String[] DESCS = {
            "Corres siempre que avances (si tienes hambre suficiente).",
            "Golpea solo al apuntar a un jugador u hostil con el arma cargada.",
            "Pasa un tótem del inventario a la mano secundaria si no tienes uno.",
            "Agranda la caja de golpe de los jugadores (slider abajo).",
            "Cada golpe sale crítico, incluso estando en el suelo.",
            "Gira la mira al jugador más cercano mientras golpeas (slider abajo)."
    };

    private static final boolean[] ON = new boolean[COUNT];
    private static boolean hitboxApplied = false;
    private static int totemCooldown = 0;

    private Cheats() {}

    public static boolean get(int id) {
        return id >= 0 && id < COUNT && ON[id];
    }

    public static boolean any() {
        for (boolean b : ON) if (b) return true;
        return false;
    }

    public static void set(int id, boolean value) {
        if (id < 0 || id >= COUNT) return;
        ON[id] = value;
        if (id == HITBOX && !value) restoreHitboxes(Minecraft.getInstance());
    }

    public static void disableAll() {
        for (int i = 0; i < COUNT; i++) ON[i] = false;
        restoreHitboxes(Minecraft.getInstance());
    }

    // ---------- Hitbox ----------
    private static AABB baseBox(Player p) {
        return p.getDimensions(p.getPose()).makeBoundingBox(p.position());
    }

    private static void applyHitboxes(Minecraft mc) {
        double grow = BoxConfig.hitboxSize / 100.0D;
        for (Player other : mc.level.players()) {
            if (other == mc.player) continue;
            other.setBoundingBox(baseBox(other).inflate(grow, grow * 0.5D, grow));
        }
        hitboxApplied = true;
    }

    private static void restoreHitboxes(Minecraft mc) {
        if (!hitboxApplied) return;
        hitboxApplied = false;
        if (mc == null || mc.level == null) return;
        for (Player other : mc.level.players()) {
            if (other == mc.player) continue;
            other.setBoundingBox(baseBox(other));
        }
    }

    // ---------- Aimbot (cada frame) ----------
    private static float yawTo(Vec3 from, Vec3 to) {
        return (float) Math.toDegrees(Math.atan2(-(to.x - from.x), to.z - from.z));
    }

    private static float pitchTo(Vec3 from, Vec3 to) {
        double dx = to.x - from.x;
        double dz = to.z - from.z;
        return (float) -Math.toDegrees(Math.atan2(to.y - from.y, Math.sqrt(dx * dx + dz * dz)));
    }

    private static Vec3 aimPoint(Player o) {
        return o.position().add(0.0D, o.getBbHeight() * 0.7D, 0.0D);
    }

    /** Se llama cada frame (dtTicks = ticks transcurridos desde el frame anterior). */
    public static void frame(Minecraft mc, float dtTicks) {
        if (!ON[AIMBOT] || mc.player == null || mc.level == null || mc.screen != null) return;
        // Solo actúa mientras golpeas (clic izquierdo) o con Auto Attack activo.
        if (!(mc.options.keyAttack.isDown() || ON[AUTO_ATTACK])) return;

        LocalPlayer p = mc.player;
        double range = BoxConfig.aimRange / 10.0D;
        Vec3 eye = p.getEyePosition();
        Player best = null;
        double bestDist = range * range;

        for (Player o : mc.level.players()) {
            if (o == p || o.isSpectator() || !o.isAlive() || !p.hasLineOfSight(o)) continue;
            double d = p.distanceToSqr(o);
            if (d > bestDist) continue;
            float yaw = yawTo(eye, aimPoint(o));
            if (Math.abs(Mth.wrapDegrees(yaw - p.getYRot())) > 75.0f) continue; // solo dentro de un cono frontal
            best = o;
            bestDist = d;
        }
        if (best == null) return;

        Vec3 aim = aimPoint(best);
        float targetYaw = yawTo(eye, aim);
        float targetPitch = pitchTo(eye, aim);
        double strength = Math.max(0.01D, Math.min(1.0D, BoxConfig.aimSmooth / 100.0D));
        float frac = (float) (1.0D - Math.pow(1.0D - strength, Math.max(0.05F, dtTicks)));

        p.setYRot(p.getYRot() + Mth.wrapDegrees(targetYaw - p.getYRot()) * frac);
        p.setXRot(Mth.clamp(p.getXRot() + (targetPitch - p.getXRot()) * frac, -90.0f, 90.0f));
    }

    /** Antes de la física del jugador (START_CLIENT_TICK). */
    public static void tickStart(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        LocalPlayer p = mc.player;
        boolean free = mc.screen == null;

        if (ON[SPRINT] && free && mc.options.keyUp.isDown() && !p.isShiftKeyDown()
                && !p.isUsingItem() && !p.horizontalCollision
                && p.getFoodData().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }

    /** Después del tick (END_CLIENT_TICK): hitbox, combate e inventario. */
    public static void tickEnd(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        LocalPlayer p = mc.player;

        if (ON[HITBOX]) applyHitboxes(mc);
        Criticals.tick(mc);

        if (ON[AUTO_ATTACK] && mc.screen == null && !p.isUsingItem()
                && mc.hitResult instanceof EntityHitResult hit) {
            Entity target = hit.getEntity();
            if (target.isAlive() && (target instanceof Player || target instanceof Enemy)
                    && p.getAttackStrengthScale(0.0F) >= 0.99F) {
                mc.gameMode.attack(p, target);
                p.swing(InteractionHand.MAIN_HAND);
            }
        }

        if (ON[AUTO_TOTEM] && mc.screen == null) {
            if (totemCooldown > 0) {
                totemCooldown--;
            } else if (!p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
                int size = p.inventoryMenu.slots.size();
                for (int slot = 9; slot < 45 && slot < size; slot++) {
                    if (p.inventoryMenu.slots.get(slot).getItem().is(Items.TOTEM_OF_UNDYING)) {
                        // Botón 40 + SWAP = intercambiar con la mano secundaria.
                        mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
                        totemCooldown = 4;
                        break;
                    }
                }
            }
        }
    }
}
